Install collection and roles using `ansible-galaxy install -r requirements.yml`
