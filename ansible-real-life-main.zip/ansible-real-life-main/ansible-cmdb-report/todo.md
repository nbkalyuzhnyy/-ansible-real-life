Demo
- mention ansible-cmdb