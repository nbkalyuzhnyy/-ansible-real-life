### Linux OS Patching 

Watch the video - [Webnar [Video](https://www.youtube.com/watch?v=sGXTfsz-3-4)]
