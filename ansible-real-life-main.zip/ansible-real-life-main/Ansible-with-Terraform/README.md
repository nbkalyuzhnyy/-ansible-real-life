## Ansible-with-Terraform

- Refer [terraform ansible lab](https://github.com/ginigangadharan/terraform-iac-usecases/tree/master/terraform-aws-ansible-lab) repository for the sameple codes and playbooks.
- See the [slides](Using-Ansible-with-Terraform.pdf) for references.
